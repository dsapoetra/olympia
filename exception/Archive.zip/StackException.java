//package com.company.exception;

/**
 * Created by dimassaputra on 4/12/16.
 */
public class StackException extends Exception {
    private String msg;
    public StackException(String msg){
        System.out.println("Sorry but stack is "+msg);
    }
    public String toString(){
        return msg;
        }
}
